package View;

import java.awt.*;

public class Colors {
    static public Color WHITE100 = new Color(0xFFFFFF);
    static public Color DARK10 = new Color(0x191919);
    static public Color DARK20 = new Color(0x202020);
    static public Color DARK30 = new Color(0x4D4D4D);
    static public Color ACCENT50 = new Color(0x8329EA);
    static public Color RED = new Color(0xCC2B2B);
    static public Color GREEN = new Color(0x2BCC40);
}
