package Controller;

import java.util.Arrays;

public class controller {
    public static double[] scan(String[] args){
        return Arrays.stream(args).mapToDouble(Double::parseDouble).toArray();
    }
    public static double[][] calcRoot(double[] nums, double[] precisions){
        double xn = 10;
        double[][] roots = new double[9][5];
        for (int j = 0; j < precisions.length; j++ ) {
            for (int i = 0; i < nums.length; i++) {
                while (Math.abs(Math.pow(xn, 2) - nums[i]) > precisions[j]) {
                    xn = 0.5 * (xn + nums[i] / xn);
                }
                roots[i][j] = xn;
            }
        }
        return roots;
    }
}
