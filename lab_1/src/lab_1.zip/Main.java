import java.util.Arrays;
import Controller.controller;

public class Main {
    public static void main(String[] args) {
        double[] nums = controller.scan(Arrays.copyOfRange(args, 9, 14));
        double[] precisions = controller.scan(Arrays.copyOfRange(args, 0, 9));
        System.out.println(Arrays.toString(precisions));
        System.out.println(Arrays.toString(nums));
    }
}