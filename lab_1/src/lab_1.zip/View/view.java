package View;

import java.util.Properties;

public class view {
    public void print(Properties arg){
        System.out.println(arg.getProperty("ro"));
    }
}
